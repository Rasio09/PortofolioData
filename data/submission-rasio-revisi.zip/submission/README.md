menjalankannya hanya install library yang ada di file requirements.txt

lalu jalankan notebook.ipynb untuk filenya proses analisis data semua disitu

untuk tampilan dashboard buka folder dashboard lalu jalankan dashboard.py dengan streamlit run dashboard.py

atau bisa dengan link ini untuk dashboardnya

https://submissiondicoding-analysis-rasio.streamlit.app/
 